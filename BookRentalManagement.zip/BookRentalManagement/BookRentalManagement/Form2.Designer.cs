﻿namespace BookRentalManagement
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.กำะฃToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ขอมลหนงสอToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.การเชาหนงสอToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.การคนหนงสอToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ขอมลพนกงานToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.รายงานToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ออกจากระบบToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.กำะฃToolStripMenuItem,
            this.รายงานToolStripMenuItem,
            this.ออกจากระบบToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(357, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // กำะฃToolStripMenuItem
            // 
            this.กำะฃToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.กำะฃToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ขอมลหนงสอToolStripMenuItem,
            this.การเชาหนงสอToolStripMenuItem,
            this.การคนหนงสอToolStripMenuItem,
            this.ขอมลพนกงานToolStripMenuItem});
            this.กำะฃToolStripMenuItem.Name = "กำะฃToolStripMenuItem";
            this.กำะฃToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.กำะฃToolStripMenuItem.Text = "ข้อมูลหลัก";
            // 
            // ขอมลหนงสอToolStripMenuItem
            // 
            this.ขอมลหนงสอToolStripMenuItem.Name = "ขอมลหนงสอToolStripMenuItem";
            this.ขอมลหนงสอToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ขอมลหนงสอToolStripMenuItem.Text = "ข้อมูลหนังสือ";
            this.ขอมลหนงสอToolStripMenuItem.Click += new System.EventHandler(this.ขอมลหนงสอToolStripMenuItem_Click);
            // 
            // การเชาหนงสอToolStripMenuItem
            // 
            this.การเชาหนงสอToolStripMenuItem.Name = "การเชาหนงสอToolStripMenuItem";
            this.การเชาหนงสอToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.การเชาหนงสอToolStripMenuItem.Text = "การเช่าหนังสือ";
            // 
            // การคนหนงสอToolStripMenuItem
            // 
            this.การคนหนงสอToolStripMenuItem.Name = "การคนหนงสอToolStripMenuItem";
            this.การคนหนงสอToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.การคนหนงสอToolStripMenuItem.Text = "การคืนหนังสือ";
            // 
            // ขอมลพนกงานToolStripMenuItem
            // 
            this.ขอมลพนกงานToolStripMenuItem.Name = "ขอมลพนกงานToolStripMenuItem";
            this.ขอมลพนกงานToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ขอมลพนกงานToolStripMenuItem.Text = "ข้อมูลพนักงาน";
            // 
            // รายงานToolStripMenuItem
            // 
            this.รายงานToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.รายงานToolStripMenuItem.Name = "รายงานToolStripMenuItem";
            this.รายงานToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.รายงานToolStripMenuItem.Text = "รายงาน";
            // 
            // ออกจากระบบToolStripMenuItem
            // 
            this.ออกจากระบบToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ออกจากระบบToolStripMenuItem.Name = "ออกจากระบบToolStripMenuItem";
            this.ออกจากระบบToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.ออกจากระบบToolStripMenuItem.Text = "ออกจากระบบ";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 317);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form2";
            this.Text = "ระบบบริหารจัดการร้านเช่าหนังสือ";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem กำะฃToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ขอมลหนงสอToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem การเชาหนงสอToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem การคนหนงสอToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ขอมลพนกงานToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem รายงานToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ออกจากระบบToolStripMenuItem;
    }
}