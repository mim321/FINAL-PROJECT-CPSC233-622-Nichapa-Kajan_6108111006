﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using BookRentalManagement.myclass;

namespace BookRentalManagement
{
    public partial class Form1 : Form
    {
        mysqlconnection_class log = new mysqlconnection_class();
        acc ac = new acc();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        try
        {
            log.connectdb.Open();
            label1.Text = "You are Connected to the MySQL Database.";
            label1.ForeColor = Color.Green;
            log.connectdb.Close();
        }
        catch
        {
            label1.Text = "Failed to connect";
        }
    }

        private void btnLog_Click(object sender, EventArgs e)
        {
            ac.username = txtUser.Text;
            ac.user_password = txtPass.Text;
            bool verify = ac.validate_User();

            if (verify)
            {
                MessageBox.Show("ยินดีต้อนรับเข้าสู่ระบบ");
                Form2 frm2 = new Form2();
                frm2.MdiParent = this.MdiParent;
                frm2.Show();

            }
            else
            {
                MessageBox.Show("โปรดตรวจสอบข้อมูลให้ถูกต้อง");
            }
        }
    }
}
