﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BookRentalManagement.myclass;

namespace BookRentalManagement
{
    public partial class Employees : Form
    {
        dataClass dc = new dataClass();
        acc ac = new acc();

        // Temporary value
        public string get_fullname;

        public Employees()
        {
            InitializeComponent();
        }

        private void Employees_Load(object sender, EventArgs e)
        {
            dc.Show_Table();
            comboBox1.DataSource = dc.datafill;
            dataGridView1.DataSource = null;
            dc.Datagrid_data();
            dataGridView1.DataSource = dc.DT;

            // pane show/off
            panel1.Visible = false;
            panel2.Visible = false;

            // update and delete fidlds
            txtUpfullname.Enabled = false;
            txtUpusername.Enabled = false;
            txtUpre.Enabled = false;
            txtUpusername.Enabled = false;
            txtUpBid.Enabled = false;
            txtUpBs.Enabled = false;
            txtUpBn.Enabled = false;
            txtUpBp.Enabled = false;
            btnUpdate.Enabled = false;
            btnDL.Enabled = false;

            // show datagrid button
            CREATE_DATAGRID_BUTTON();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dc.search_text = comboBox1.Text;

            if (comboBox1.Text == "-----เลือกชื่อเต็ม-----")
            {
                // load all user data
                dataGridView1.DataSource = null;
                dc.Datagrid_data();
                dataGridView1.DataSource = dc.DT;
            }
            else
            {
                // show only selected fullname
                dataGridView1.DataSource = null;
                dc.filter_data();
                dataGridView1.DataSource = dc.DT;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // show pane1
            panel1.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // close pane1
            panel1.Visible = false;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            // showing password
            if (checkBox1.Checked)
            {
                // show
                Passwordtxt.UseSystemPasswordChar = false;
                Repasstxt.UseSystemPasswordChar = false;

            }
            else
            {
                // hide by using password chapacter
                Passwordtxt.UseSystemPasswordChar = true;
                Repasstxt.UseSystemPasswordChar = true;
            }
        }

        private void btnb_Click(object sender, EventArgs e)
        {
            // check password if match
            if (Passwordtxt.Text == Repasstxt.Text)
            {
                // submit
                ac.username = Usernametxt.Text;
                ac.user_password = Passwordtxt.Text;
                ac.user_fullname = Fullnametxt.Text;
                ac.user_Bid = Bookidtxt.Text;
                ac.user_Bn = Booknametxt.Text;
                ac.user_Bp = Bookpricetxt.Text;
                ac.user_Bs = Bookstatustxt.Text;
                ac.ADD_USER();
                MessageBox.Show("login" + Usernametxt.Text + "added to the database successfully!");
                // update datagridview
                dataGridView1.DataSource = null;
                dc.Datagrid_data();
                dataGridView1.DataSource = dc.DT;
                // shoud close the pane1 if successfully
                panel1.Visible = false;
            }
            else
            {
                MessageBox.Show("Check your password!");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // close pane2
            panel2.Visible = false;
        }

        private void CREATE_DATAGRID_BUTTON()
        {
            DataGridViewButtonColumn btn_col = new DataGridViewButtonColumn();
            btn_col.HeaderText = "UPDATE/DELETE";
            btn_col.Text = "Click here";
            btn_col.Name = "btncol";
            btn_col.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(btn_col);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // click button
            DataGridView senderGrid = (DataGridView)sender;
            try
            {
                if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    get_fullname = (dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString());
                    txtUpfullname.Text = get_fullname;
                    txtUpusername.Text = (dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString());
                    txtUppass.Text = (dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString());
                    txtUpre.Text = (dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString());
                    txtUpBid.Text = (dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString());
                    txtUpBs.Text = (dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString());
                    txtUpBn.Text = (dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString());
                    txtUpBp.Text = (dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString());

                    panel2.Visible = true;
                }
            }
            catch
            {
                MessageBox.Show("Dont click the header!");
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            // update chack box
            if (checkBox5.Checked)
            {
                txtUpfullname.Enabled = true;
                txtUpusername.Enabled = true;
                txtUpre.Enabled = true;
                txtUpusername.Enabled = true;
                btnUpdate.Enabled = true;
            }
            else
            {
                txtUpfullname.Enabled = false;
                txtUpusername.Enabled = false;
                txtUpre.Enabled = false;
                txtUpusername.Enabled = false;
                btnUpdate.Enabled = false;
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            // delete chack box
            if (checkBox6.Checked)
            {
                txtUpfullname.Text = get_fullname;
                btnDL.Enabled = true;
            }
            else
            {
                btnDL.Enabled = false;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // for update button
            if (txtUpusername.Text == txtUpre.Text)
            {
                // where
                ac._fullname = get_fullname;
                // set
                ac.username = txtUpusername.Text;
                ac.user_password = txtUpusername.Text;
                ac.user_fullname = txtUpfullname.Text;
                ac.UPDATE_USER();
                // update the datagridview
                dataGridView1.DataSource = null;
                dc.Datagrid_data();
                dataGridView1.DataSource = dc.DT;
                // refresh datagrid button
                dataGridView1.Columns.Remove("btncol");
                CREATE_DATAGRID_BUTTON();

                MessageBox.Show("Update Succesfully!");
                panel2.Visible = false;
            }
            else
            {
                MessageBox.Show("Please check you password!");
            }
        }

        private void btnDL_Click(object sender, EventArgs e)
        {
            // delete button
            DialogResult dialog = MessageBox.Show("Are you sure?", "DELETE THIS USER?", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                ac._fullname = get_fullname;
                ac.DELETE_USER();
                // update the datagridview
                dataGridView1.DataSource = null;
                dc.Datagrid_data();
                dataGridView1.DataSource = dc.DT;
                // refresh datagrid button
                dataGridView1.Columns.Remove("btncol");
                CREATE_DATAGRID_BUTTON();

                ////panel2.Visible = false;
                MessageBox.Show("User Delete");
            }
            else
            {

            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
