﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using BookRentalManagement.myclass;

namespace BookRentalManagement
{
    class dataClass : mysqlconnection_class
    {
        public List<string> datafill = new List<string>();
        public string search_text;
        private string query = " SELECT * FROM login";

        public DataTable DT = new DataTable();
        private DataSet DS = new DataSet();

        public void Show_Table()
        {
            datafill.Clear();
            MySqlDataReader rd;

            using (var cmd = new MySqlCommand())
            {
                connectdb.Open();
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connectdb;

                datafill.Add("-----เลือกชื่อเต็ม-----");
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    datafill.Add(rd[1].ToString()); // Username
                }
                connectdb.Close();

            }
        }

        public void Datagrid_data()
        {
            DT.Clear();
            MySqlDataAdapter DA = new MySqlDataAdapter(query, connectdb);
            DA.Fill(DS);
            DT = DS.Tables[0];
        }

        public void filter_data()
        {
            DT.Clear();
            string query_filter = "SELECT * FROM login WHERE username = '" + search_text + "'";
            MySqlDataAdapter DA = new MySqlDataAdapter(query_filter, connectdb);
            DA.Fill(DS);
            DT = DS.Tables[0];
        }
    }
}
