﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using BookRentalManagement.myclass;


namespace BookRentalManagement.myclass
{
    class acc : mysqlconnection_class
    {
        public string username { set; get; }
        public string user_fullname { set; get; }
        public string user_password { set; get; }
        public string user_Bid { set; get; }
        public string user_Bn { set; get; }
        public string user_Bp { set; get; }
        public string user_Bs { set; get; }

        // create properties for where databass get data
        public string _fullname { set; get; }


        public bool validate_User()
        {
            bool check = false;
            connectdb.Open();
            MySqlDataReader rd;
            using (var cmd = new MySqlCommand())
            {
                cmd.CommandText = "SELECT * FROM login WHERE username=@user AND password=@pass";
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Connection = connectdb;

                // Parameters
                cmd.Parameters.Add("@user", MySqlDbType.VarChar).Value = username;
                cmd.Parameters.Add("@pass", MySqlDbType.VarChar).Value = user_password;

                rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    check = true;
                    user_fullname = rd.GetString("fullname");
                }
                connectdb.Close();

            }
            return check;
        }

        public void ADD_USER()
        {
            connectdb.Open();
            string query = "INSERT INTO login(username,fullname,password,Book_id,Book_name,Book_price,Book_status)Values(@us, @fn, @ps,@bi,@bn,@bp,@bs)";
            using (var cmd = new MySqlCommand())
            {
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connectdb;

                cmd.Parameters.Add("@us", MySqlDbType.VarChar).Value = username;
                cmd.Parameters.Add("@fn", MySqlDbType.VarChar).Value = user_fullname;
                cmd.Parameters.Add("@ps", MySqlDbType.VarChar).Value = user_password;
                cmd.Parameters.Add("@bi", MySqlDbType.VarChar).Value = user_Bid;
                cmd.Parameters.Add("@bn", MySqlDbType.VarChar).Value = user_Bn;
                cmd.Parameters.Add("@bp", MySqlDbType.VarChar).Value = user_Bp;
                cmd.Parameters.Add("@bs", MySqlDbType.VarChar).Value = user_Bs;



                cmd.ExecuteNonQuery();
                connectdb.Close();

            }
        }

        public void UPDATE_USER()
        {
            connectdb.Open();
            string query = "UPDATE login SET username=@user, password=@pass, fullname=@name, Book_id=@BID ,Book_name=@BN,Book_price=@BP,Book_status=@BS WHERE fullname=@fn";
            using (var cmd = new MySqlCommand())
            {
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connectdb;
                // WHERE
                cmd.Parameters.Add("@fn", MySqlDbType.VarChar).Value = _fullname;
                // set
                cmd.Parameters.Add("@user", MySqlDbType.VarChar).Value = username;
                cmd.Parameters.Add("@pass", MySqlDbType.VarChar).Value = user_password;
                cmd.Parameters.Add("@name", MySqlDbType.VarChar).Value = user_fullname;
                cmd.Parameters.Add("@BID", MySqlDbType.VarChar).Value = user_Bid;
                cmd.Parameters.Add("@BN", MySqlDbType.VarChar).Value = user_Bn;
                cmd.Parameters.Add("@BP", MySqlDbType.VarChar).Value = user_Bp;
                cmd.Parameters.Add("@BS", MySqlDbType.VarChar).Value = user_Bp;

                cmd.ExecuteNonQuery();
                connectdb.Close();
            }
        }

        public void DELETE_USER()
        {
            connectdb.Open();
            string query = "DELETE FROM login WHERE fullname=@fn";
            using (var cmd = new MySqlCommand())
            {
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connectdb;
                // WHERE
                cmd.Parameters.Add("@fn", MySqlDbType.VarChar).Value = _fullname;

                cmd.ExecuteNonQuery();
                connectdb.Close();
            }
        }
    }
}
